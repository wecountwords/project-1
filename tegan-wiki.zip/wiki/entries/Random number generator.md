#random number generator

Algorithm or formula that will generate a pseudo random number.