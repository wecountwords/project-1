# JavaScript - testing editing

this page is testing the ability to edit an article